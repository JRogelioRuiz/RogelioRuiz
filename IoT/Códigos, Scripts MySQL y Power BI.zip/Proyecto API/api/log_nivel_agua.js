const mysql = require("../database/db");

function insertLog_Nivel_Agua(req, res) {
    var query = "INSERT INTO log_nivel_agua (id_dispositivo, fecha, nivel_agua) VALUES (?, now(), ?);";

    var id_dispositivo = req.body.id_dispositivo;
    var nivel_agua = req.body.nivel_agua;

    var connection = mysql.getConnection();

    connection.connect((error) => {
        if (error) throw error;
        
        var params = [id_dispositivo, nivel_agua];

        connection.execute(query, params, (error, data, fields) => {
            if (error) {
                res.status(500);
                res.send(error.message);
            }
            else {
                console.log(data);
                res.json({
                    status: 200,
                    message: "Log de nivel de agua insertado correctamente",
                    affectedRows: data.affectedRows
                });
            }
            connection.end();
        });
    });
}

module.exports = {insertLog_Nivel_Agua};