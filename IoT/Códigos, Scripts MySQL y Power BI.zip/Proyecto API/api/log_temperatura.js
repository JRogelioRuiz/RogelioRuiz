const mysql = require("../database/db");

// Método para insertar un log de temperatura
function insertLog_Temperatura(req, res) {
    // se construye la consulta
    var query = "INSERT INTO log_temperatura (id_dispositivo, fecha, temp) VALUES (?, now(), ?);";
    var query2 = "INSERT INTO ajuste_temperatura (log_id, accion) VALUES (LAST_INSERT_ID(), ?);";

    // parametros para la consulta
    var id_dispositivo = req.body.id_dispositivo;
    var temp = req.body.temp;
    var accion = req.body.accion;

    // se abre la conexion a la base de datos
    var connection = mysql.getConnection();

    // se ejecuta la consulta
    connection.connect((error) => {
        if (error) throw error;
        
        // se pasan los parametros a la variable params
        var params = [id_dispositivo, temp];

        connection.execute(query, params, (error, data, fields) => {
            if (error) {
                // si hay un error se envia el mensaje de error al cliente
                res.status(500);
                res.send(error.message);
            }
            else {
                // se imprime el resultado de la consulta en la terminal y se envia la respuesta al cliente
                console.log(data);

                if (accion != "null") {
                    var params2 = [accion];
                    connection.execute(query2, params2, (error, data, fields) => {
                        if (error) {
                            // si hay un error se envia el mensaje de error al cliente
                            res.status(500);
                            res.send(error.message);
                        }
                        else {
                            console.log(data);
                            res.json({
                                status: 200,
                                message: "Log de temperatura insertado correctamente",
                                affectedRows: data.affectedRows
                            });
                        }
                    });
                }
                else {
                    res.json({
                        status: 200,
                        message: "Log de temperatura insertado correctamente",
                        affectedRows: data.affectedRows
                    });
                }
            }
            // se finaliza la conexión
            connection.end();
        });  
    });
};

// se exportan las funciones para que puedan ser usadas en el archivo de rutas
module.exports = {insertLog_Temperatura};