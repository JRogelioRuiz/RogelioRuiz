const mysql = require('../database/db');

function insertLog_Comida(req, res) {
    var query = "INSERT INTO log_comida (id_dispositivo, fecha, evento) VALUES (?, now(), ?);";

    var id_dispositivo = req.body.id_dispositivo;
    var evento = req.body.evento;

    var connection = mysql.getConnection();

    connection.connect((error) => {
        if (error) throw error;

        var params = [id_dispositivo, evento];

        connection.execute(query, params, (error, data, fields) => {
            if (error) {
                res.status(500);
                res.send(error.message);
            }
            else {
                res.status(200);
                res.json({
                    status: 200,
                    message: "Log de comida insertado correctamente",
                    affectedRows: data.affectedRows
                });
            }
            connection.end();
         });
    });
}

module.exports = {insertLog_Comida};