INSERT INTO pet_store.log_comida (id_dispositivo,fecha,evento) VALUES
	 (3,'2023-10-31 06:31:07','comida dispensada'),
	 (3,'2023-10-31 18:32:52','comida dispensada'),
	 (3,'2023-11-01 05:35:10','comida dispensada'),
	 (3,'2023-11-01 17:26:06','comida dispensada'),
	 (3,'2023-11-02 02:47:14','comida dispensada'),
	 (3,'2023-11-02 13:34:44','comida dispensada'),
	 (3,'2023-11-02 23:57:00','comida dispensada'),
	 (3,'2023-11-03 08:15:30','comida dispensada'),
	 (3,'2023-11-04 12:45:22','comida dispensada'),
	 (3,'2023-11-04 20:10:18','comida dispensada');
INSERT INTO pet_store.log_comida (id_dispositivo,fecha,evento) VALUES
	 (3,'2023-11-05 10:20:45','comida dispensada'),
	 (3,'2023-11-06 14:30:12','comida dispensada'),
	 (3,'2023-11-06 22:45:28','comida dispensada'),
	 (3,'2023-11-07 07:55:19','comida dispensada'),
	 (3,'2023-11-08 16:10:05','comida dispensada'),
	 (3,'2023-11-08 21:45:33','comida dispensada'),
	 (3,'2023-11-09 11:25:40','comida dispensada'),
	 (3,'2023-11-10 18:30:15','comida dispensada'),
	 (3,'2023-11-10 23:40:50','comida dispensada'),
	 (3,'2023-11-11 09:15:22','comida dispensada');
INSERT INTO pet_store.log_comida (id_dispositivo,fecha,evento) VALUES
	 (3,'2023-11-12 10:20:45','comida dispensada'),
	 (3,'2023-11-13 14:30:12','comida dispensada'),
	 (3,'2023-11-13 22:45:28','comida dispensada'),
	 (3,'2023-11-14 07:55:19','comida dispensada'),
	 (3,'2023-11-15 16:10:05','comida dispensada'),
	 (3,'2023-11-15 21:45:33','comida dispensada'),
	 (3,'2023-11-16 11:25:40','comida dispensada'),
	 (3,'2023-11-16 19:15:59','comida dispensada'),
	 (3,'2023-11-16 23:39:10','comida dispensada'),
	 (3,'2023-11-17 18:30:15','comida dispensada');
INSERT INTO pet_store.log_comida (id_dispositivo,fecha,evento) VALUES
	 (3,'2023-11-17 23:40:50','comida dispensada'),
	 (3,'2023-11-18 09:15:22','comida dispensada'),
	 (3,'2023-11-19 10:20:45','comida dispensada'),
	 (3,'2023-11-20 14:30:12','comida dispensada'),
	 (3,'2023-11-20 22:45:28','comida dispensada'),
	 (3,'2023-11-21 07:55:19','comida dispensada'),
	 (3,'2023-11-22 16:10:05','comida dispensada'),
	 (3,'2023-11-22 21:45:33','comida dispensada'),
	 (3,'2023-11-23 11:25:40','comida dispensada'),
	 (3,'2023-11-24 18:30:15','comida dispensada');
INSERT INTO pet_store.log_comida (id_dispositivo,fecha,evento) VALUES
	 (3,'2023-11-24 23:40:50','comida dispensada'),
	 (3,'2023-11-25 09:15:22','comida dispensada'),
	 (3,'2023-11-26 10:20:45','comida dispensada'),
	 (3,'2023-11-27 14:30:12','comida dispensada'),
	 (3,'2023-11-27 22:45:28','comida dispensada'),
	 (3,'2023-11-28 07:55:19','comida dispensada'),
	 (3,'2023-11-29 16:10:05','comida dispensada'),
	 (3,'2023-11-29 21:45:33','comida dispensada');
