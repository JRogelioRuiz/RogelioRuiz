const mysql = require("../database/db");

function insertLog_Transparencia_Agua(req, res) {
    var query = "INSERT INTO log_transparencia_agua (id_dispositivo, fecha, transparencia) VALUES (?, now(), ?);";
    var query2 = "INSERT INTO limpieza_agua (log_id, resultado) VALUES (LAST_INSERT_ID(), ?);";

    var id_dispositivo = req.body.id_dispositivo;
    var transparencia = req.body.transparencia;
    var resultado = req.body.resultado;

    var connection = mysql.getConnection();

    connection.connect((error) => {
        if (error) throw error;
       
        var params = [id_dispositivo, transparencia];

        connection.execute(query, params, (error, data, fields) => {
            if (error) {
                res.status(500);
                res.send(error.message);
            }
            else {
                console.log(data);
                if (resultado != "null"){
                    var params2 = [resultado];
                    connection.execute(query2, params2, (error, data, fields) => {
                        if (error) {
                            res.status(500);
                            res.send(error.message);
                        }
                        else {
                            console.log(data);
                            res.json({
                                status: 200,
                                message: "Log de transparencia de agua insertado correctamente",
                                affectedRows: data.affectedRows
                            });
                        }

                    });
                }
                else {
                    res.json({
                        status: 200,
                        message: "Log de transparencia de agua insertado correctamente",
                        affectedRows: data.affectedRows
                    });                  

                }
            }
            connection.end();
        });
    });
}

module.exports = {insertLog_Transparencia_Agua};