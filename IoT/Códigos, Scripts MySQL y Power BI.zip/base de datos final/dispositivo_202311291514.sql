INSERT INTO pet_store.dispositivo (`desc`,id_habitat) VALUES
	 ('Regulador de temperatura',1),
	 ('Sensor de movimiento',2),
	 ('Dispensador de comida',2),
	 ('Dispensador de agua',2),
	 ('Limpieza de agua',3);
