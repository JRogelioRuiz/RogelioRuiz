const mysql = require('mysql2');

/**
 * Método que configura un objeto conexión y lo regresa a quien lo solicite.
 */
function getConnection(){
  const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "@american1354A", // Aquí va la contraseña de la base de datos
    database: "pet_store"// Aquí va el nombre de la base de datos
  });

  return connection;
}

module.exports = {getConnection};
