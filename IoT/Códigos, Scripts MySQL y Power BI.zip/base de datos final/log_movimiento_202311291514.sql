INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-04 15:40:46','inferior'),
	 (2,'2023-11-27 00:00:00','tobogán'),
	 (2,'2023-11-27 00:30:00','inferior'),
	 (2,'2023-11-27 01:00:00','superior'),
	 (2,'2023-11-27 01:30:00','inferior'),
	 (2,'2023-11-27 02:00:00','inferior'),
	 (2,'2023-11-27 02:30:00','inferior'),
	 (2,'2023-11-27 03:00:00','inferior'),
	 (2,'2023-11-27 03:30:00','inferior'),
	 (2,'2023-11-27 04:00:00','inferior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-27 04:30:00','superior'),
	 (2,'2023-11-27 05:00:00','inferior'),
	 (2,'2023-11-27 05:30:00','superior'),
	 (2,'2023-11-27 06:00:00','inferior'),
	 (2,'2023-11-27 06:30:00','tobogán'),
	 (2,'2023-11-27 07:00:00','superior'),
	 (2,'2023-11-27 07:30:00','inferior'),
	 (2,'2023-11-27 08:00:00','superior'),
	 (2,'2023-11-27 08:30:00','superior'),
	 (2,'2023-11-27 09:00:00','inferior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-27 09:30:00','superior'),
	 (2,'2023-11-27 10:00:00','tobogán'),
	 (2,'2023-11-27 10:30:00','tobogán'),
	 (2,'2023-11-27 11:00:00','superior'),
	 (2,'2023-11-27 11:30:00','inferior'),
	 (2,'2023-11-27 12:00:00','tobogán'),
	 (2,'2023-11-27 12:30:00','superior'),
	 (2,'2023-11-27 13:00:00','tobogán'),
	 (2,'2023-11-27 13:30:00','inferior'),
	 (2,'2023-11-27 14:00:00','inferior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-27 14:30:00','superior'),
	 (2,'2023-11-27 15:00:00','inferior'),
	 (2,'2023-11-27 15:30:00','superior'),
	 (2,'2023-11-27 16:00:00','superior'),
	 (2,'2023-11-27 16:30:00','superior'),
	 (2,'2023-11-27 17:00:00','superior'),
	 (2,'2023-11-27 17:30:00','tobogán'),
	 (2,'2023-11-27 18:00:00','tobogán'),
	 (2,'2023-11-27 18:30:00','superior'),
	 (2,'2023-11-27 19:00:00','inferior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-27 19:30:00','inferior'),
	 (2,'2023-11-27 20:00:00','inferior'),
	 (2,'2023-11-27 20:30:00','tobogán'),
	 (2,'2023-11-27 21:00:00','tobogán'),
	 (2,'2023-11-27 21:30:00','superior'),
	 (2,'2023-11-27 22:00:00','tobogán'),
	 (2,'2023-11-27 22:30:00','superior'),
	 (2,'2023-11-27 23:00:00','tobogán'),
	 (2,'2023-11-27 23:30:00','inferior'),
	 (2,'2023-11-28 00:00:00','superior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-28 00:30:00','superior'),
	 (2,'2023-11-28 01:00:00','inferior'),
	 (2,'2023-11-28 01:30:00','inferior'),
	 (2,'2023-11-28 02:00:00','inferior'),
	 (2,'2023-11-28 02:30:00','inferior'),
	 (2,'2023-11-28 03:00:00','inferior'),
	 (2,'2023-11-28 03:30:00','tobogán'),
	 (2,'2023-11-28 04:00:00','tobogán'),
	 (2,'2023-11-28 04:30:00','tobogán'),
	 (2,'2023-11-28 05:00:00','inferior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-28 05:30:00','tobogán'),
	 (2,'2023-11-28 06:00:00','inferior'),
	 (2,'2023-11-28 06:30:00','inferior'),
	 (2,'2023-11-28 07:00:00','inferior'),
	 (2,'2023-11-28 07:30:00','inferior'),
	 (2,'2023-11-28 08:00:00','inferior'),
	 (2,'2023-11-28 08:30:00','superior'),
	 (2,'2023-11-28 09:00:00','inferior'),
	 (2,'2023-11-28 09:30:00','inferior'),
	 (2,'2023-11-28 10:00:00','inferior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-28 10:30:00','inferior'),
	 (2,'2023-11-28 11:00:00','superior'),
	 (2,'2023-11-28 11:30:00','superior'),
	 (2,'2023-11-28 12:00:00','superior'),
	 (2,'2023-11-28 12:30:00','superior'),
	 (2,'2023-11-28 13:00:00','tobogán'),
	 (2,'2023-11-28 13:30:00','inferior'),
	 (2,'2023-11-28 14:00:00','inferior'),
	 (2,'2023-11-28 14:30:00','superior'),
	 (2,'2023-11-28 15:00:00','inferior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-28 15:30:00','tobogán'),
	 (2,'2023-11-28 16:00:00','tobogán'),
	 (2,'2023-11-28 16:30:00','tobogán'),
	 (2,'2023-11-28 17:00:00','inferior'),
	 (2,'2023-11-28 17:30:00','inferior'),
	 (2,'2023-11-28 18:00:00','inferior'),
	 (2,'2023-11-28 18:30:00','superior'),
	 (2,'2023-11-28 19:00:00','inferior'),
	 (2,'2023-11-28 19:30:00','superior'),
	 (2,'2023-11-28 20:00:00','superior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-28 20:30:00','inferior'),
	 (2,'2023-11-28 21:00:00','superior'),
	 (2,'2023-11-28 21:30:00','superior'),
	 (2,'2023-11-28 22:00:00','superior'),
	 (2,'2023-11-28 22:30:00','inferior'),
	 (2,'2023-11-28 23:00:00','inferior'),
	 (2,'2023-11-28 23:30:00','superior'),
	 (2,'2023-11-29 00:00:00','inferior'),
	 (2,'2023-11-29 00:30:00','inferior'),
	 (2,'2023-11-29 01:00:00','inferior');
INSERT INTO pet_store.log_movimiento (id_dispositivo,fecha,zona) VALUES
	 (2,'2023-11-29 01:30:00','tobogán');
