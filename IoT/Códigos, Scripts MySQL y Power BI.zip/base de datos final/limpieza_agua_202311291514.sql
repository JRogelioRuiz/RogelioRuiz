INSERT INTO pet_store.limpieza_agua (log_id,resultado) VALUES
	 (345,'limpieza exitosa'),
	 (690,'limpieza exitosa');
