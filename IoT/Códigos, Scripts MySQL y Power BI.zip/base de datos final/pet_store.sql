DROP DATABASE IF EXISTS pet_store;
CREATE SCHEMA pet_store;
USE pet_store;

/*TABLAS*/
/*Core*/
CREATE TABLE `habitat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `desc` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `dispositivo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `desc` varchar(64),
  `id_habitat` INT,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_habitat`) REFERENCES `habitat`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

/*Regulador de temperatura*/
CREATE TABLE `log_temperatura` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_dispositivo` INT NOT NULL,
  `fecha` DATETIME NOT NULL,
  `temp` FLOAT NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE `ajuste_temperatura` (
  `log_id` INT NOT NULL,
  `accion` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`log_id`),
  FOREIGN KEY (`log_id`) REFERENCES `log_temperatura`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

/*Sensor de movimiento*/
CREATE TABLE `log_movimiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_dispositivo` INT NOT NULL,
  `fecha` DATETIME NOT NULL,
  `zona` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

/*Dispensador comida*/
CREATE TABLE `log_comida` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_dispositivo` INT NOT NULL,
  `fecha` DATETIME NOT NULL,
  `evento` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

/*Dispensador agua*/
CREATE TABLE `log_nivel_agua` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_dispositivo` INT NOT NULL,
  `fecha` DATETIME NOT NULL,
  `nivel_agua` FLOAT NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

/*Limpieza de agua*/
CREATE TABLE `log_transparencia_agua` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_dispositivo` INT NOT NULL,
  `fecha` DATETIME NOT NULL,
  `transparencia` FLOAT NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
);
/*Example inserts into limpieaza agua*/
INSERT INTO log_transparencia_agua (id_dispositivo, fecha, transparencia) VALUES (5, now(), );

CREATE TABLE `limpieza_agua` (
  `log_id` INT NOT NULL,
  `resultado` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`log_id`),
  FOREIGN KEY (`log_id`) REFERENCES `log_transparencia_agua`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

/*INSERTS*/
INSERT INTO habitat VALUES
(1, "habitat de tortuga"),
(2, "hábitat de hamster"),
(3, "pecera");
SELECT * FROM habitat;

INSERT INTO dispositivo VALUES
(1, "Regulador de temperatura", 1),
(2, "Sensor de movimiento", 1),
(3, "Dispensador de comida", 2),
(4, "Dispensador de agua", 2),
(5, "Limpieza de agua", 3);
SELECT * FROM dispositivo;

/*INSERTS DE API*/
INSERT INTO log_temperatura (id_dispositivo, fecha, temp) VALUES  (1, NOW(), 16);
INSERT INTO ajuste_temperatura (log_id, accion) VALUES (last_insert_id(), "se prendió la calefacción");
SELECT * FROM log_temperatura;
SELECT * FROM ajuste_temperatura;

INSERT INTO log_movimiento (id_dispositivo, fecha, zona) VALUES (3, NOW(), "superior");
SELECT * FROM log_movimiento;

INSERT INTO log_comida (id_dispositivo, fecha, evento) VALUES (2, NOW(), "comida dispensada");
SELECT * FROM log_comida;

INSERT INTO log_nivel_agua (id_dispositivo, fecha, nivel_agua) VALUES (2, NOW(), 987);
SELECT * FROM log_nivel_agua;

INSERT INTO log_transparencia_agua (id_dispositivo, fecha, transparencia) VALUES (2, NOW(), 987);
INSERT INTO limpieza_agua (log_id, resultado) VALUES (last_insert_id(), "se limpió el agua exitósamente");
SELECT * FROM log_transparencia_agua;
SELECT * FROM limpieza_agua;

INSERT INTO ajuste_temperatura (log_id, accion) VALUES (LAST_INSERT_ID(), "hola");
select LAST_INSERT_ID()