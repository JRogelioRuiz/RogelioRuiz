INSERT INTO pet_store.habitat (`desc`) VALUES
	 ('habitat de tortuga'),
	 ('hábitat de hamster'),
	 ('pecera');
