const express = require('express');
const log_TemperaturaController = require("../api/log_temperatura.js");
const log_MovimientoController = require("../api/log_movimiento.js");
const log_ComidaController = require("../api/log_comida.js");
const log_NivelAguaController = require("../api/log_nivel_agua.js");
const log_TransparenciaAguaController = require("../api/log_transparencia_agua.js");
const router = express.Router();

// Rutas para logs de temperatura
router.post("/api/log_temperatura", log_TemperaturaController.insertLog_Temperatura);

// Rutas para logs de movimiento
router.post("/api/log_movimiento", log_MovimientoController.insertLog_Movimiento);

// Rutas para logs de comida
router.post("/api/log_comida", log_ComidaController.insertLog_Comida);

// Rutas para logs de nivel de agua
router.post("/api/log_nivel_agua", log_NivelAguaController.insertLog_Nivel_Agua);

// Rutas para logs de transparencia de agua
router.post("/api/log_transparencia_agua", log_TransparenciaAguaController.insertLog_Transparencia_Agua);

module.exports = router;