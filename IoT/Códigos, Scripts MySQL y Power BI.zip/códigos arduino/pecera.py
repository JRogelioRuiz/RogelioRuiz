from oled import OLED
import ssd1306
import utime
import machine
import time
import network
import urequests
from machine import Pin, Timer, I2C, ADC

# hardware
drain_valve = Pin(12, Pin.OUT)
fill_valve = Pin(13, Pin.OUT)
drain_valve.on() # actually turns it off
fill_valve.on() # actually turns it off
machine.PWM(machine.Pin(15))
adc = ADC(0)
display = OLED(res=(128, 32), scl=5, sda=4)
a_sw = Pin(14, Pin.OUT)
valve_stopwatch = 0

# readings
read_sum = 0
read_count = 0
read_avg = None
stopwatch = 0

# settings
fill_timeout = 2000
drain_timeout = 120000
average_span = 5000


# loop
main_loop = None

def note_to_freq(note):
    # Frequency values for notes from C3 to B5
    note_frequencies = {
        'C3': 130.81, 'C#3': 138.59, 'D3': 146.83, 'D#3': 155.56, 'E3': 164.81,
        'F3': 174.61, 'F#3': 185.00, 'G3': 196.00, 'G#3': 207.65, 'A3': 220.00,
        'A#3': 233.08, 'B3': 246.94, 'C4': 261.63, 'C#4': 277.18, 'D4': 293.66,
        'D#4': 311.13, 'E4': 329.63, 'F4': 349.23, 'F#4': 369.99, 'G4': 392.00,
        'G#4': 415.30, 'A4': 440.00, 'A#4': 466.16, 'B4': 493.88, 'C5': 523.25,
        'C#5': 554.37, 'D5': 587.33, 'D#5': 622.25, 'E5': 659.25, 'F5': 698.46,
        'F#5': 739.99, 'G5': 783.99, 'G#5': 830.61, 'A5': 880.00, 'A#5': 932.33,
        'B5': 987.77
    }
    return note_frequencies.get(note, 0)  # Return 0 if note not found

def play_jingle(pin_num, filename):
    buzzer = machine.PWM(machine.Pin(pin_num))
    
    # Read the file and parse the notes and durations
    with open(filename, 'r') as file:
        jingle_data = file.readlines()

    def play_note(timer):
        nonlocal jingle_data
        if jingle_data:
            note_info = jingle_data.pop(0).strip().split(',')
            note, duration = note_info[0], int(note_info[1])
            freq = note_to_freq(note)
            if freq > 0:
                buzzer.freq(int(freq))
                buzzer.duty(512)
                time.sleep_ms(duration)
                buzzer.duty(0)
            if jingle_data:
                timer.init(period=duration, mode=machine.Timer.ONE_SHOT, callback=play_note)
        else:
            timer.deinit()  # Stop the timer if no more notes to play

    # Initialize and start the timer
    timer = machine.Timer(-1)
    timer.init(period=0, mode=machine.Timer.ONE_SHOT, callback=play_note)

def connect_to_wifi(ssid, password):
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    
    if not wlan.isconnected():
        print('Connecting to network...')
        wlan.connect(ssid, password)
        
        # Wait for connect or fail
        max_attempts = 10
        attempts = 0
        while not wlan.isconnected() and attempts < max_attempts:
            attempts += 1
            time.sleep(1)
        
        # Check if connected
        if wlan.isconnected():
            print('Network connected!')
            print('IP address:', wlan.ifconfig()[0])
            return True
        else:
            print('Unable to connect to the network.')
            return False
    else:
        print('Already connected.')
        return True

def log_sensor_reading(transparency, result = "null"):
    if connect_to_wifi("Galaxy A528642", "speu2473"):
        url = 'http://192.168.243.80:3001/api/log_transparencia_agua'  # Replace with your actual URL
        data = {
            'id_dispositivo': 5,
            'transparencia': transparency,
            'resultado': result
        }

        try:
            response = urequests.post(url, json=data)
            response.close()  # It's important to close the response
            return True
        except Exception as e:
            print('Failed to send data:', e)
            return False
    else:
        print("Wi-Fi connection failed.")
        return False

def start_readings():
	global read_sum, read_count, read_avg, stopwatch
	read_sum = 0
	read_count = 0
	read_avg = None
	stopwatch = utime.ticks_ms()

def take_reading(reading):
	global read_sum, read_count
	read_sum += reading
	read_count += 1

def update_avg():
	global read_avg, read_sum, read_count, stopwatch
	
	# update average, restart readings
	read_avg = read_sum // read_count
	read_sum = 0
	read_count = 0
	stopwatch = utime.ticks_ms()

def init_clean_state(transparency = 0):
	global main_loop, valve_stopwatch
	
	def assess_loop():
		global main_loop
		
		# take reading
		water_level = adc.read()
		take_reading(water_level)
		
		# after certain time
		elapsed = utime.ticks_diff(utime.ticks_ms(), stopwatch)
		print(elapsed)
		if (elapsed >= 3000):
			update_avg()
			# initiate drain cycle
			valve_stopwatch = utime.ticks_ms()
			main_loop = drain_loop
		
		display.write("Assessing:" + str(elapsed) + "\nWaterLevel: " + str(water_level) + "\nAverage:" + str(read_avg))
	
	def drain_loop():
		global main_loop, valve_stopwatch
		
		# take reading
		water_level = adc.read()
		take_reading(water_level)
		
		# update water level average every 1 second
		if (utime.ticks_diff(utime.ticks_ms(), stopwatch) >= 2000):
			update_avg()
		
		v_elapsed = utime.ticks_diff(utime.ticks_ms(), valve_stopwatch)
		display.write("Draining:" + str(v_elapsed) + "\nWaterLevel: " + str(water_level) + "\nAverage:" + str(read_avg))
		
		# When water level crosses threshold, or timeout has elapsed
		if (read_avg <= 200 if read_avg else False) or v_elapsed >= drain_timeout:
			# transition to fill phase
			drain_valve.on()  # Deactivate drain valve
			valve_stopwatch = utime.ticks_ms()  # Reset stopwatch
			main_loop = fill_loop
		else:
			drain_valve.off() # activate if not active

	def fill_loop():
		global main_loop, valve_stopwatch
		
		# take reading
		water_level = adc.read()
		take_reading(water_level)
		
		# update water level average every 1 second
		if (utime.ticks_diff(utime.ticks_ms(), stopwatch) >= 2000):
			update_avg()
		
		v_elapsed = utime.ticks_diff(utime.ticks_ms(), valve_stopwatch)
		display.write("Filling:" + str(v_elapsed) + "\nWaterLevel: " + str(water_level) + "\nAverage:" + str(read_avg))
		
		# When water level crosses threshold, or timeout has elapsed
		if (read_avg >= 400 if read_avg else False) or v_elapsed >= fill_timeout:
			# transition to fill phase
			fill_valve.on()  # Deactivate fill valve
			valve_stopwatch = utime.ticks_ms()  # Reset stopwatch
			log_sensor_reading(read_avg, "Water cleaned successfully!")
			play_jingle(15, 'jingle.csv')
			init_light_sensor()
		else:
			fill_valve.off() # activate if not active
	
	# start readings
	a_sw.off()
	start_readings()
	
	# set main loop
	main_loop = assess_loop

def init_light_sensor():
	global main_loop
	
	def loop():
		global read_sum, read_count, read_avg, stopwatch
		
		# take reading
		light = adc.read()
		take_reading(light)
		
		# if average interval has elapsed
		elapsed = utime.ticks_diff(utime.ticks_ms(), stopwatch)
		print(elapsed)
		if elapsed >= average_span:
			update_avg()
			if read_avg <= 200:
				pass
				init_clean_state(read_avg)
				# after finished, post with status report
			else:
				log_sensor_reading(read_avg)
				
		
		# display data on screen
		output = "LightLevel:" + str(light) + "\n"
		output += "Average:" + str(read_avg) + "\n"
		display.write(output)
	
	a_sw.on() # switch to photoresistor
	start_readings() # start taking readings
	main_loop = loop # set main loop

init_light_sensor()
while True:
	main_loop()
	utime.sleep(0.1)