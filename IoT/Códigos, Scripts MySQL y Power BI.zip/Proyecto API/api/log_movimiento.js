const mysql = require("../database/db");

function insertLog_Movimiento(req, res) {
    
        var query = "INSERT INTO log_movimiento (id_dispositivo, fecha, zona) VALUES (?, now(), ?);";
    
        var id_dispositivo = req.body.id_dispositivo;
        var zona = req.body.zona;
    
        var connection = mysql.getConnection();
    
        connection.connect((error) => {
            if (error) throw error;
            
            var params = [id_dispositivo, zona];
    
            connection.execute(query, params, (error, data, fields) => {
                if (error) {
                    res.status(500);
                    res.send(error.message);
                }
                else {
                    console.log(data);
                    res.json({
                        status: 200,
                        message: "Log de movimiento insertado correctamente",
                        affectedRows: data.affectedRows
                    });
                }
                connection.end();
            });  
        });
}

module.exports = {insertLog_Movimiento};