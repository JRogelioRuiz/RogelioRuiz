INSERT INTO pet_store.ajuste_temperatura (log_id,accion) VALUES
	 (139,'Foco apagado, ventilador encendido'),
	 (165,'Foco apagado, ventilador encendido'),
	 (190,'Foco encendido, ventilador apagado'),
	 (219,'Foco apagado, ventilador encendido'),
	 (226,'Foco apagado, ventilador encendido'),
	 (232,'Foco encendido, ventilador apagado'),
	 (234,'Foco apagado, ventilador encendido'),
	 (235,'Foco encendido, ventilador apagado'),
	 (282,'Foco apagado, ventilador encendido'),
	 (287,'Foco encendido, ventilador apagado');
INSERT INTO pet_store.ajuste_temperatura (log_id,accion) VALUES
	 (370,'Foco apagado, ventilador encendido'),
	 (373,'Foco encendido, ventilador apagado'),
	 (427,'Foco apagado, ventilador encendido'),
	 (432,'Foco encendido, ventilador apagado'),
	 (466,'Foco apagado, ventilador encendido'),
	 (488,'Foco encendido, ventilador apagado'),
	 (496,'Foco apagado, ventilador encendido');
